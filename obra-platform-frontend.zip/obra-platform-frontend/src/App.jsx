import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Star, MapPin, Clock, User, Briefcase, Plus, Search, Phone, Globe, Instagram, LogIn, LogOut, UserPlus, Building2 } from 'lucide-react'
import './App.css'

const API_BASE_URL = 'https://5001-ilg0y5txrooh7qstfuriv-f548a8af.manus.computer/api'

// Dados de exemplo para demonstração
const sampleProjects = [
  {
    id: 1,
    title: "Instalação de Portão Eletrônico",
    description: "Preciso instalar um portão eletrônico na entrada da minha casa. O portão já foi comprado, preciso apenas da instalação e configuração do sistema de abertura automática.",
    category: "eletrica",
    location: "São Paulo, SP",
    budget_min: 800,
    budget_max: 1500,
    status: "open",
    client_name: "João Silva",
    created_at: "2024-01-15"
  },
  {
    id: 2,
    title: "Reforma Completa do Banheiro",
    description: "Reforma completa de banheiro incluindo troca de azulejos, louças, instalação hidráulica e elétrica. Banheiro de aproximadamente 6m².",
    category: "hidraulica",
    location: "Rio de Janeiro, RJ",
    budget_min: 5000,
    budget_max: 8000,
    status: "open",
    client_name: "Maria Santos",
    created_at: "2024-01-14"
  },
  {
    id: 3,
    title: "Pintura Externa da Casa",
    description: "Pintura externa de casa térrea com aproximadamente 120m² de área pintável. Incluir preparação da superfície e duas demãos de tinta.",
    category: "pintura",
    location: "Belo Horizonte, MG",
    budget_min: 2000,
    budget_max: 3500,
    status: "open",
    client_name: "Carlos Oliveira",
    created_at: "2024-01-13"
  }
]

const sampleProviders = [
  {
    id: 1,
    name: "Elétrica Pro",
    email: "contato@eletricapro.com",
    phone: "(11) 99999-1234",
    description: "Especialistas em instalações elétricas residenciais e comerciais. 15 anos de experiência no mercado.",
    website: "https://eletricapro.com",
    instagram: "@eletricapro",
    average_rating: 4.8,
    total_reviews: 127,
    user_type: "provider"
  },
  {
    id: 2,
    name: "Reformas & Cia",
    email: "orcamento@reformasecia.com.br",
    phone: "(21) 98888-5678",
    description: "Reformas completas, hidráulica, alvenaria e acabamentos. Equipe qualificada e materiais de primeira linha.",
    website: "https://reformasecia.com.br",
    instagram: "@reformasecia",
    average_rating: 4.6,
    total_reviews: 89,
    user_type: "provider"
  },
  {
    id: 3,
    name: "Pintura Perfeita",
    email: "contato@pinturaperfeita.com",
    phone: "(31) 97777-9012",
    description: "Serviços de pintura residencial e comercial. Trabalhamos com as melhores marcas de tinta do mercado.",
    website: "",
    instagram: "@pinturaperfeita",
    average_rating: 4.9,
    total_reviews: 203,
    user_type: "provider"
  }
]

const categories = [
  { value: 'eletrica', label: 'Elétrica' },
  { value: 'hidraulica', label: 'Hidráulica' },
  { value: 'pintura', label: 'Pintura' },
  { value: 'alvenaria', label: 'Alvenaria' },
  { value: 'marcenaria', label: 'Marcenaria' },
  { value: 'jardinagem', label: 'Jardinagem' },
  { value: 'limpeza', label: 'Limpeza' },
  { value: 'outros', label: 'Outros' }
]

function App() {
  const [projects, setProjects] = useState(sampleProjects)
  const [providers, setProviders] = useState(sampleProviders)
  const [loading, setLoading] = useState(false)
  const [activeTab, setActiveTab] = useState('projects')
  
  // Estados de autenticação
  const [user, setUser] = useState(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const [showRegisterDialog, setShowRegisterDialog] = useState(false)

  // Estados para formulários de autenticação
  const [loginForm, setLoginForm] = useState({
    email: '',
    password: ''
  })

  const [registerForm, setRegisterForm] = useState({
    name: '',
    email: '',
    password: '',
    user_type: '',
    phone: '',
    description: '',
    website: '',
    instagram: ''
  })

  // Estados para formulários
  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    category: '',
    location: '',
    budget_min: '',
    budget_max: '',
    client_id: 1 // Simulando usuário logado
  })

  const [newProvider, setNewProvider] = useState({
    name: '',
    email: '',
    phone: '',
    description: '',
    website: '',
    instagram: '',
    user_type: 'provider'
  })

  // Verificar autenticação ao carregar a página
  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/check`, {
        credentials: 'include'
      })
      const data = await response.json()
      
      if (data.authenticated) {
        setUser(data.user)
        setIsAuthenticated(true)
        // Define a aba inicial baseada no tipo de usuário
        if (data.user_type === 'provider') {
          setActiveTab('projects')
        } else {
          setActiveTab('providers')
        }
      }
    } catch (error) {
      console.error('Erro ao verificar autenticação:', error)
    }
  }

  const handleLogin = async () => {
    if (!loginForm.email || !loginForm.password) {
      alert('Por favor, preencha todos os campos.')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(loginForm)
      })

      const data = await response.json()

      if (response.ok) {
        setUser(data.user)
        setIsAuthenticated(true)
        setShowLoginDialog(false)
        setLoginForm({ email: '', password: '' })
        
        // Define a aba inicial baseada no tipo de usuário
        if (data.user.user_type === 'provider') {
          setActiveTab('projects')
        } else {
          setActiveTab('providers')
        }
        
        alert('Login realizado com sucesso!')
      } else {
        alert(data.error || 'Erro ao fazer login')
      }
    } catch (error) {
      console.error('Erro ao fazer login:', error)
      alert('Erro ao conectar com o servidor')
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async () => {
    if (!registerForm.name || !registerForm.email || !registerForm.password || !registerForm.user_type) {
      alert('Por favor, preencha todos os campos obrigatórios.')
      return
    }

    setLoading(true)
    try {
      const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(registerForm)
      })

      const data = await response.json()

      if (response.ok) {
        setUser(data.user)
        setIsAuthenticated(true)
        setShowRegisterDialog(false)
        setRegisterForm({
          name: '',
          email: '',
          password: '',
          user_type: '',
          phone: '',
          description: '',
          website: '',
          instagram: ''
        })
        
        // Define a aba inicial baseada no tipo de usuário
        if (data.user.user_type === 'provider') {
          setActiveTab('projects')
        } else {
          setActiveTab('providers')
        }
        
        alert('Cadastro realizado com sucesso!')
      } else {
        alert(data.error || 'Erro ao fazer cadastro')
      }
    } catch (error) {
      console.error('Erro ao fazer cadastro:', error)
      alert('Erro ao conectar com o servidor')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE_URL}/auth/logout`, {
        method: 'POST',
        credentials: 'include'
      })
      
      setUser(null)
      setIsAuthenticated(false)
      setActiveTab('projects')
      alert('Logout realizado com sucesso!')
    } catch (error) {
      console.error('Erro ao fazer logout:', error)
    }
  }

  const createProject = async () => {
    if (!isAuthenticated) {
      alert('Você precisa estar logado para criar um projeto.')
      return
    }

    if (user.user_type !== 'client') {
      alert('Apenas clientes podem criar projetos.')
      return
    }

    if (!newProject.title || !newProject.description || !newProject.category || !newProject.location) {
      alert('Por favor, preencha todos os campos obrigatórios.')
      return
    }

    const project = {
      id: projects.length + 1,
      ...newProject,
      budget_min: newProject.budget_min ? parseFloat(newProject.budget_min) : null,
      budget_max: newProject.budget_max ? parseFloat(newProject.budget_max) : null,
      status: 'open',
      client_name: user.name,
      created_at: new Date().toISOString().split('T')[0]
    }

    setProjects([project, ...projects])
    setNewProject({
      title: '',
      description: '',
      category: '',
      location: '',
      budget_min: '',
      budget_max: '',
      client_id: user.id
    })
    alert('Projeto criado com sucesso!')
  }

  const createProvider = async () => {
    if (!newProvider.name || !newProvider.email) {
      alert('Por favor, preencha pelo menos o nome e email.')
      return
    }

    const provider = {
      id: providers.length + 1,
      ...newProvider,
      average_rating: 0,
      total_reviews: 0
    }

    setProviders([provider, ...providers])
    setNewProvider({
      name: '',
      email: '',
      phone: '',
      description: '',
      website: '',
      instagram: '',
      user_type: 'provider'
    })
    alert('Prestador cadastrado com sucesso!')
  }

  const formatCurrency = (value) => {
    if (!value) return 'Não informado'
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  const formatCategory = (category) => {
    const categoryMap = {
      'eletrica': 'Elétrica',
      'hidraulica': 'Hidráulica',
      'pintura': 'Pintura',
      'alvenaria': 'Alvenaria',
      'marcenaria': 'Marcenaria',
      'jardinagem': 'Jardinagem',
      'limpeza': 'Limpeza',
      'outros': 'Outros'
    }
    return categoryMap[category] || category
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < Math.floor(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
      />
    ))
  }

  // Determina quais abas mostrar baseado no tipo de usuário
  const getVisibleTabs = () => {
    if (!isAuthenticated) {
      return ['projects', 'providers', 'auth']
    }
    
    if (user.user_type === 'provider') {
      return ['projects', 'b2b', 'create']
    } else {
      return ['providers', 'create']
    }
  }

  const visibleTabs = getVisibleTabs()

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Briefcase className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Plataforma de Obras</h1>
            </div>
            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <>
                  <div className="flex items-center space-x-2">
                    <User className="h-5 w-5 text-gray-600" />
                    <span className="text-sm text-gray-700">Olá, {user.name}</span>
                    <Badge variant="outline" className={user.user_type === 'provider' ? 'text-blue-600 border-blue-600' : 'text-green-600 border-green-600'}>
                      {user.user_type === 'provider' ? 'Prestador' : 'Cliente'}
                    </Badge>
                  </div>
                  <Button variant="outline" size="sm" onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sair
                  </Button>
                </>
              ) : (
                <>
                  <Badge variant="outline" className="text-green-600 border-green-600">
                    {projects.length} Projetos Ativos
                  </Badge>
                  <Badge variant="outline" className="text-blue-600 border-blue-600">
                    {providers.length} Prestadores
                  </Badge>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className={`grid w-full grid-cols-${visibleTabs.length}`}>
            {visibleTabs.includes('projects') && (
              <TabsTrigger value="projects">Projetos</TabsTrigger>
            )}
            {visibleTabs.includes('providers') && (
              <TabsTrigger value="providers">Prestadores</TabsTrigger>
            )}
            {visibleTabs.includes('b2b') && (
              <TabsTrigger value="b2b">B2B</TabsTrigger>
            )}
            {visibleTabs.includes('create') && (
              <TabsTrigger value="create">Criar</TabsTrigger>
            )}
            {visibleTabs.includes('auth') && (
              <TabsTrigger value="auth">Login/Cadastro</TabsTrigger>
            )}
          </TabsList>

          {/* Projetos Tab */}
          {visibleTabs.includes('projects') && (
            <TabsContent value="projects" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-gray-900">Projetos Disponíveis</h2>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input placeholder="Buscar projetos..." className="pl-10 w-64" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map((project) => (
                  <Card key={project.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{project.title}</CardTitle>
                        <Badge variant={project.status === 'open' ? 'default' : 'secondary'}>
                          {project.status === 'open' ? 'Aberto' : 'Em Andamento'}
                        </Badge>
                      </div>
                      <CardDescription className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-1" />
                        {project.location}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4 line-clamp-3">{project.description}</p>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-600">Categoria:</span>
                          <Badge variant="outline">{formatCategory(project.category)}</Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-600">Orçamento:</span>
                          <span className="text-sm text-gray-900">
                            {project.budget_min && project.budget_max 
                              ? `${formatCurrency(project.budget_min)} - ${formatCurrency(project.budget_max)}`
                              : 'A combinar'
                            }
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-gray-600">Cliente:</span>
                          <span className="text-sm text-gray-900">{project.client_name}</span>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t">
                        <Button className="w-full" onClick={() => alert('Funcionalidade de orçamento será implementada em breve!')}>
                          Enviar Orçamento
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          )}

          {/* Prestadores Tab */}
          {visibleTabs.includes('providers') && (
            <TabsContent value="providers" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-gray-900">Prestadores de Serviço</h2>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input placeholder="Buscar prestadores..." className="pl-10 w-64" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {providers.map((provider) => (
                  <Card key={provider.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{provider.name}</CardTitle>
                          <div className="flex items-center space-x-1">
                            {renderStars(provider.average_rating || 0)}
                            <span className="text-sm text-gray-600 ml-2">
                              ({provider.total_reviews || 0} avaliações)
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4 line-clamp-3">
                        {provider.description || 'Prestador de serviços qualificado'}
                      </p>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-gray-600">Email:</span>
                          <span className="text-sm text-gray-900">{provider.email}</span>
                        </div>
                        {provider.phone && (
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-gray-600" />
                            <span className="text-sm text-gray-900">{provider.phone}</span>
                          </div>
                        )}
                        {provider.website && (
                          <div className="flex items-center space-x-2">
                            <Globe className="h-4 w-4 text-gray-600" />
                            <a href={provider.website} target="_blank" rel="noopener noreferrer" 
                               className="text-sm text-blue-600 hover:underline">
                              Ver site
                            </a>
                          </div>
                        )}
                        {provider.instagram && (
                          <div className="flex items-center space-x-2">
                            <Instagram className="h-4 w-4 text-gray-600" />
                            <span className="text-sm text-gray-900">{provider.instagram}</span>
                          </div>
                        )}
                      </div>
                      <div className="mt-4 pt-4 border-t">
                        <Button className="w-full" onClick={() => alert('Funcionalidade de perfil completo será implementada em breve!')}>
                          Ver Perfil Completo
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          )}

          {/* B2B Tab */}
          {visibleTabs.includes('b2b') && (
            <TabsContent value="b2b" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-gray-900">Rede B2B - Prestadores</h2>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input placeholder="Buscar parceiros..." className="pl-10 w-64" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {providers.map((provider) => (
                  <Card key={provider.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center">
                          <Building2 className="h-6 w-6 text-purple-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{provider.name}</CardTitle>
                          <div className="flex items-center space-x-1">
                            {renderStars(provider.average_rating || 0)}
                            <span className="text-sm text-gray-600 ml-2">
                              ({provider.total_reviews || 0} avaliações)
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 mb-4 line-clamp-3">
                        {provider.description || 'Prestador de serviços qualificado'}
                      </p>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-gray-600">Email:</span>
                          <span className="text-sm text-gray-900">{provider.email}</span>
                        </div>
                        {provider.phone && (
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-gray-600" />
                            <span className="text-sm text-gray-900">{provider.phone}</span>
                          </div>
                        )}
                      </div>
                      <div className="mt-4 pt-4 border-t">
                        <Button className="w-full" variant="outline" onClick={() => alert('Funcionalidade de parceria B2B será implementada em breve!')}>
                          Conectar para Parceria
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          )}

          {/* Criar Tab */}
          {visibleTabs.includes('create') && (
            <TabsContent value="create" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Criar Projeto - Apenas para clientes */}
                {(!isAuthenticated || user.user_type === 'client') && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Plus className="h-5 w-5 mr-2" />
                        Criar Novo Projeto
                      </CardTitle>
                      <CardDescription>
                        Publique seu projeto e receba orçamentos de prestadores qualificados
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="project-title">Título do Projeto *</Label>
                        <Input
                          id="project-title"
                          placeholder="Ex: Instalação de portão eletrônico"
                          value={newProject.title}
                          onChange={(e) => setNewProject({...newProject, title: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="project-category">Categoria *</Label>
                        <Select value={newProject.category} onValueChange={(value) => setNewProject({...newProject, category: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione uma categoria" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((cat) => (
                              <SelectItem key={cat.value} value={cat.value}>
                                {cat.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="project-location">Localização *</Label>
                        <Input
                          id="project-location"
                          placeholder="Ex: São Paulo, SP"
                          value={newProject.location}
                          onChange={(e) => setNewProject({...newProject, location: e.target.value})}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="budget-min">Orçamento Mínimo (R$)</Label>
                          <Input
                            id="budget-min"
                            type="number"
                            placeholder="1000"
                            value={newProject.budget_min}
                            onChange={(e) => setNewProject({...newProject, budget_min: e.target.value})}
                          />
                        </div>
                        <div>
                          <Label htmlFor="budget-max">Orçamento Máximo (R$)</Label>
                          <Input
                            id="budget-max"
                            type="number"
                            placeholder="5000"
                            value={newProject.budget_max}
                            onChange={(e) => setNewProject({...newProject, budget_max: e.target.value})}
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="project-description">Descrição Detalhada *</Label>
                        <Textarea
                          id="project-description"
                          placeholder="Descreva detalhadamente o que precisa ser feito..."
                          rows={4}
                          value={newProject.description}
                          onChange={(e) => setNewProject({...newProject, description: e.target.value})}
                        />
                      </div>
                      <Button onClick={createProject} className="w-full">
                        Publicar Projeto
                      </Button>
                    </CardContent>
                  </Card>
                )}

                {/* Cadastrar Prestador - Apenas para não autenticados */}
                {!isAuthenticated && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <User className="h-5 w-5 mr-2" />
                        Cadastrar como Prestador
                      </CardTitle>
                      <CardDescription>
                        Cadastre-se para receber solicitações de orçamento
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="provider-name">Nome Completo *</Label>
                        <Input
                          id="provider-name"
                          placeholder="Seu nome completo"
                          value={newProvider.name}
                          onChange={(e) => setNewProvider({...newProvider, name: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="provider-email">Email *</Label>
                        <Input
                          id="provider-email"
                          type="email"
                          placeholder="seu@email.com"
                          value={newProvider.email}
                          onChange={(e) => setNewProvider({...newProvider, email: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="provider-phone">Telefone</Label>
                        <Input
                          id="provider-phone"
                          placeholder="(11) 99999-9999"
                          value={newProvider.phone}
                          onChange={(e) => setNewProvider({...newProvider, phone: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="provider-website">Website</Label>
                        <Input
                          id="provider-website"
                          placeholder="https://seusite.com"
                          value={newProvider.website}
                          onChange={(e) => setNewProvider({...newProvider, website: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="provider-instagram">Instagram</Label>
                        <Input
                          id="provider-instagram"
                          placeholder="@seuinstagram"
                          value={newProvider.instagram}
                          onChange={(e) => setNewProvider({...newProvider, instagram: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label htmlFor="provider-description">Descrição dos Serviços</Label>
                        <Textarea
                          id="provider-description"
                          placeholder="Descreva seus serviços e experiência..."
                          rows={4}
                          value={newProvider.description}
                          onChange={(e) => setNewProvider({...newProvider, description: e.target.value})}
                        />
                      </div>
                      <Button onClick={createProvider} className="w-full">
                        Cadastrar Prestador
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          )}

          {/* Auth Tab */}
          {visibleTabs.includes('auth') && (
            <TabsContent value="auth" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Login */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <LogIn className="h-5 w-5 mr-2" />
                      Fazer Login
                    </CardTitle>
                    <CardDescription>
                      Entre na sua conta para acessar todas as funcionalidades
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="login-email">Email *</Label>
                      <Input
                        id="login-email"
                        type="email"
                        placeholder="seu@email.com"
                        value={loginForm.email}
                        onChange={(e) => setLoginForm({...loginForm, email: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="login-password">Senha *</Label>
                      <Input
                        id="login-password"
                        type="password"
                        placeholder="Sua senha"
                        value={loginForm.password}
                        onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                      />
                    </div>
                    <Button onClick={handleLogin} className="w-full" disabled={loading}>
                      {loading ? 'Entrando...' : 'Entrar'}
                    </Button>
                  </CardContent>
                </Card>

                {/* Register */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <UserPlus className="h-5 w-5 mr-2" />
                      Criar Conta
                    </CardTitle>
                    <CardDescription>
                      Cadastre-se como cliente ou prestador de serviços
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="register-name">Nome Completo *</Label>
                      <Input
                        id="register-name"
                        placeholder="Seu nome completo"
                        value={registerForm.name}
                        onChange={(e) => setRegisterForm({...registerForm, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="register-email">Email *</Label>
                      <Input
                        id="register-email"
                        type="email"
                        placeholder="seu@email.com"
                        value={registerForm.email}
                        onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="register-password">Senha *</Label>
                      <Input
                        id="register-password"
                        type="password"
                        placeholder="Sua senha"
                        value={registerForm.password}
                        onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label htmlFor="register-user-type">Tipo de Usuário *</Label>
                      <Select value={registerForm.user_type} onValueChange={(value) => setRegisterForm({...registerForm, user_type: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="client">Cliente</SelectItem>
                          <SelectItem value="provider">Prestador de Serviços</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="register-phone">Telefone</Label>
                      <Input
                        id="register-phone"
                        placeholder="(11) 99999-9999"
                        value={registerForm.phone}
                        onChange={(e) => setRegisterForm({...registerForm, phone: e.target.value})}
                      />
                    </div>
                    {registerForm.user_type === 'provider' && (
                      <>
                        <div>
                          <Label htmlFor="register-description">Descrição dos Serviços</Label>
                          <Textarea
                            id="register-description"
                            placeholder="Descreva seus serviços e experiência..."
                            rows={3}
                            value={registerForm.description}
                            onChange={(e) => setRegisterForm({...registerForm, description: e.target.value})}
                          />
                        </div>
                        <div>
                          <Label htmlFor="register-website">Website</Label>
                          <Input
                            id="register-website"
                            placeholder="https://seusite.com"
                            value={registerForm.website}
                            onChange={(e) => setRegisterForm({...registerForm, website: e.target.value})}
                          />
                        </div>
                        <div>
                          <Label htmlFor="register-instagram">Instagram</Label>
                          <Input
                            id="register-instagram"
                            placeholder="@seuinstagram"
                            value={registerForm.instagram}
                            onChange={(e) => setRegisterForm({...registerForm, instagram: e.target.value})}
                          />
                        </div>
                      </>
                    )}
                    <Button onClick={handleRegister} className="w-full" disabled={loading}>
                      {loading ? 'Cadastrando...' : 'Criar Conta'}
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          )}
        </Tabs>
      </main>
    </div>
  )
}

export default App

