import os
import sys
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

# Adiciona o diretório raiz do projeto ao PATH para importações relativas
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 
                                             os.pardir)))

app = Flask(__name__)

# Configuração de sessões
app.config['SECRET_KEY'] = 'sua-chave-secreta-super-segura-aqui'  # Em produção, use uma chave mais segura
app.config['SESSION_COOKIE_SECURE'] = False  # Em produção, defina como True se usar HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# Configuração do CORS para permitir cookies/sessões
CORS(app, supports_credentials=True, origins=['*'])

# Configuração do banco de dados SQLite
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

# Importa os modelos de dados
from src.models.user import User, Project, Quote, Review

# Cria as tabelas no banco de dados
with app.app_context():
    db.create_all()

# Importa e registra as rotas
from src.routes.user import user_bp
from src.routes.project import project_bp
from src.routes.quote import quote_bp
from src.routes.review import review_bp
from src.routes.auth import auth_bp

app.register_blueprint(auth_bp, url_prefix="/api/auth")
app.register_blueprint(user_bp, url_prefix="/api/users")
app.register_blueprint(project_bp, url_prefix="/api/projects")
app.register_blueprint(quote_bp, url_prefix="/api/quotes")
app.register_blueprint(review_bp, url_prefix="/api/reviews")

@app.route("/api/health")
def health_check():
    return {"status": "ok", "message": "API funcionando corretamente"}

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5001)

