from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from enum import Enum
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class UserType(Enum):
    CLIENT = "client"
    PROVIDER = "provider"

class ServiceCategory(Enum):
    ELETRICA = "eletrica"
    HIDRAULICA = "hidraulica"
    PINTURA = "pintura"
    ALVENARIA = "alvenaria"
    MARCENARIA = "marcenaria"
    JARDINAGEM = "jardinagem"
    LIMPEZA = "limpeza"
    OUTROS = "outros"

class ProjectStatus(Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    user_type = db.Column(db.Enum(UserType), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Campos específicos para prestadores
    description = db.Column(db.Text, nullable=True)
    website = db.Column(db.String(200), nullable=True)
    instagram = db.Column(db.String(100), nullable=True)
    facebook = db.Column(db.String(100), nullable=True)
    
    # Relacionamentos
    projects_as_client = db.relationship('Project', foreign_keys='Project.client_id', backref='client', lazy='dynamic')
    projects_as_provider = db.relationship('Project', foreign_keys='Project.provider_id', backref='provider', lazy='dynamic')
    quotes_sent = db.relationship('Quote', backref='provider', lazy='dynamic')
    reviews_given = db.relationship('Review', foreign_keys='Review.reviewer_id', backref='reviewer', lazy='dynamic')
    reviews_received = db.relationship('Review', foreign_keys='Review.reviewed_id', backref='reviewed', lazy='dynamic')

    def set_password(self, password):
        """Define a senha do usuário com hash"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Verifica se a senha está correta"""
        return check_password_hash(self.password_hash, password)

    def update_last_login(self):
        """Atualiza o último login do usuário"""
        self.last_login = datetime.utcnow()

    def __repr__(self):
        return f'<User {self.name}>'

    def to_dict(self, include_sensitive=False):
        data = {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'user_type': self.user_type.value if self.user_type else None,
            'description': self.description,
            'website': self.website,
            'instagram': self.instagram,
            'facebook': self.facebook,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
        
        if include_sensitive:
            data['password_hash'] = self.password_hash
            
        return data

    def get_average_rating(self):
        reviews = self.reviews_received.all()
        if not reviews:
            return 0
        return sum(review.rating for review in reviews) / len(reviews)

    def get_total_reviews(self):
        return self.reviews_received.count()

class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.Enum(ServiceCategory), nullable=False)
    location = db.Column(db.String(200), nullable=False)
    budget_min = db.Column(db.Float, nullable=True)
    budget_max = db.Column(db.Float, nullable=True)
    status = db.Column(db.Enum(ProjectStatus), default=ProjectStatus.OPEN)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    client_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    provider_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    quotes = db.relationship('Quote', backref='project', lazy='dynamic', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Project {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'category': self.category.value if self.category else None,
            'location': self.location,
            'budget_min': self.budget_min,
            'budget_max': self.budget_max,
            'status': self.status.value if self.status else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'client_id': self.client_id,
            'provider_id': self.provider_id,
            'client_name': self.client.name if self.client else None,
            'provider_name': self.provider.name if self.provider else None
        }

class Quote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=False)
    estimated_duration = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_accepted = db.Column(db.Boolean, default=False)
    
    # Relacionamentos
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    provider_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    def __repr__(self):
        return f'<Quote {self.id} - R${self.price}>'

    def to_dict(self):
        return {
            'id': self.id,
            'price': self.price,
            'description': self.description,
            'estimated_duration': self.estimated_duration,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_accepted': self.is_accepted,
            'project_id': self.project_id,
            'provider_id': self.provider_id,
            'provider_name': self.provider.name if self.provider else None,
            'provider_rating': self.provider.get_average_rating() if self.provider else 0
        }

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 estrelas
    comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    reviewer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    reviewed_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)

    def __repr__(self):
        return f'<Review {self.rating} stars>'

    def to_dict(self):
        return {
            'id': self.id,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'reviewer_id': self.reviewer_id,
            'reviewed_id': self.reviewed_id,
            'project_id': self.project_id,
            'reviewer_name': self.reviewer.name if self.reviewer else None
        }

