from flask import Blueprint, request, jsonify
from src.models.user import db, Review, User, Project

review_bp = Blueprint('review', __name__)

@review_bp.route('/reviews', methods=['GET'])
def get_reviews():
    """Listar todas as avaliações"""
    try:
        reviews = Review.query.all()
        return jsonify([review.to_dict() for review in reviews])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@review_bp.route('/reviews', methods=['POST'])
def create_review():
    """Criar uma nova avaliação"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['rating', 'reviewer_id', 'reviewed_id', 'project_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Validar rating (1-5)
        if not isinstance(data['rating'], int) or data['rating'] < 1 or data['rating'] > 5:
            return jsonify({'error': 'Rating deve ser um número entre 1 e 5'}), 400
        
        # Verificar se o projeto existe
        project = Project.query.get(data['project_id'])
        if not project:
            return jsonify({'error': 'Projeto não encontrado'}), 404
        
        # Verificar se os usuários existem
        reviewer = User.query.get(data['reviewer_id'])
        reviewed = User.query.get(data['reviewed_id'])
        if not reviewer or not reviewed:
            return jsonify({'error': 'Usuário não encontrado'}), 404
        
        # Verificar se já existe uma avaliação para este projeto entre estes usuários
        existing_review = Review.query.filter_by(
            reviewer_id=data['reviewer_id'],
            reviewed_id=data['reviewed_id'],
            project_id=data['project_id']
        ).first()
        
        if existing_review:
            return jsonify({'error': 'Você já avaliou este usuário para este projeto'}), 400
        
        review = Review(
            rating=data['rating'],
            comment=data.get('comment'),
            reviewer_id=data['reviewer_id'],
            reviewed_id=data['reviewed_id'],
            project_id=data['project_id']
        )
        
        db.session.add(review)
        db.session.commit()
        
        return jsonify(review.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@review_bp.route('/reviews/<int:review_id>', methods=['GET'])
def get_review(review_id):
    """Obter uma avaliação específica"""
    try:
        review = Review.query.get_or_404(review_id)
        return jsonify(review.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@review_bp.route('/reviews/user/<int:user_id>', methods=['GET'])
def get_reviews_for_user(user_id):
    """Listar avaliações recebidas por um usuário"""
    try:
        user = User.query.get_or_404(user_id)
        reviews = Review.query.filter_by(reviewed_id=user_id).all()
        return jsonify([review.to_dict() for review in reviews])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@review_bp.route('/reviews/by-user/<int:user_id>', methods=['GET'])
def get_reviews_by_user(user_id):
    """Listar avaliações feitas por um usuário"""
    try:
        user = User.query.get_or_404(user_id)
        reviews = Review.query.filter_by(reviewer_id=user_id).all()
        return jsonify([review.to_dict() for review in reviews])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@review_bp.route('/reviews/project/<int:project_id>', methods=['GET'])
def get_reviews_for_project(project_id):
    """Listar avaliações de um projeto específico"""
    try:
        project = Project.query.get_or_404(project_id)
        reviews = Review.query.filter_by(project_id=project_id).all()
        return jsonify([review.to_dict() for review in reviews])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

