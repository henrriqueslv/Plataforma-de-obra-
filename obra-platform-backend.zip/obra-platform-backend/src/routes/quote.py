from flask import Blueprint, request, jsonify
from src.models.user import db, Quote, Project, User

quote_bp = Blueprint('quote', __name__)

@quote_bp.route('/quotes', methods=['GET'])
def get_quotes():
    """Listar todos os orçamentos"""
    try:
        quotes = Quote.query.all()
        return jsonify([quote.to_dict() for quote in quotes])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quote_bp.route('/quotes', methods=['POST'])
def create_quote():
    """Criar um novo orçamento"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['price', 'description', 'project_id', 'provider_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se o projeto existe
        project = Project.query.get(data['project_id'])
        if not project:
            return jsonify({'error': 'Projeto não encontrado'}), 404
        
        # Verificar se o prestador existe
        provider = User.query.get(data['provider_id'])
        if not provider:
            return jsonify({'error': 'Prestador não encontrado'}), 404
        
        # Verificar se já existe um orçamento deste prestador para este projeto
        existing_quote = Quote.query.filter_by(
            project_id=data['project_id'],
            provider_id=data['provider_id']
        ).first()
        
        if existing_quote:
            return jsonify({'error': 'Você já enviou um orçamento para este projeto'}), 400
        
        quote = Quote(
            price=data['price'],
            description=data['description'],
            estimated_duration=data.get('estimated_duration'),
            project_id=data['project_id'],
            provider_id=data['provider_id']
        )
        
        db.session.add(quote)
        db.session.commit()
        
        return jsonify(quote.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quote_bp.route('/quotes/<int:quote_id>', methods=['GET'])
def get_quote(quote_id):
    """Obter um orçamento específico"""
    try:
        quote = Quote.query.get_or_404(quote_id)
        return jsonify(quote.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quote_bp.route('/quotes/<int:quote_id>/accept', methods=['POST'])
def accept_quote(quote_id):
    """Aceitar um orçamento"""
    try:
        quote = Quote.query.get_or_404(quote_id)
        
        # Verificar se o orçamento já foi aceito
        if quote.is_accepted:
            return jsonify({'error': 'Este orçamento já foi aceito'}), 400
        
        # Marcar o orçamento como aceito
        quote.is_accepted = True
        
        # Atualizar o projeto com o prestador escolhido
        project = quote.project
        project.provider_id = quote.provider_id
        project.status = 'in_progress'
        
        # Rejeitar todos os outros orçamentos do mesmo projeto
        other_quotes = Quote.query.filter_by(project_id=quote.project_id).filter(Quote.id != quote_id).all()
        for other_quote in other_quotes:
            other_quote.is_accepted = False
        
        db.session.commit()
        
        return jsonify({
            'message': 'Orçamento aceito com sucesso',
            'quote': quote.to_dict(),
            'project': project.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@quote_bp.route('/quotes/project/<int:project_id>', methods=['GET'])
def get_quotes_by_project(project_id):
    """Listar orçamentos de um projeto específico"""
    try:
        project = Project.query.get_or_404(project_id)
        quotes = Quote.query.filter_by(project_id=project_id).all()
        return jsonify([quote.to_dict() for quote in quotes])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@quote_bp.route('/quotes/provider/<int:provider_id>', methods=['GET'])
def get_quotes_by_provider(provider_id):
    """Listar orçamentos de um prestador específico"""
    try:
        provider = User.query.get_or_404(provider_id)
        quotes = Quote.query.filter_by(provider_id=provider_id).all()
        return jsonify([quote.to_dict() for quote in quotes])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

