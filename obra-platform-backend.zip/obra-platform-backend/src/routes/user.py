from flask import Blueprint, request, jsonify
from src.models.user import db, User, UserType

user_bp = Blueprint('user', __name__)

@user_bp.route('/users', methods=['GET'])
def get_users():
    """Listar todos os usuários"""
    try:
        users = User.query.all()
        return jsonify([user.to_dict() for user in users])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users', methods=['POST'])
def create_user():
    """Criar um novo usuário"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['name', 'email', 'user_type']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se o email já existe
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user:
            return jsonify({'error': 'Email já cadastrado'}), 400
        
        # Verificar se o tipo de usuário é válido
        try:
            user_type = UserType(data['user_type'])
        except ValueError:
            return jsonify({'error': 'Tipo de usuário inválido'}), 400
        
        user = User(
            name=data['name'],
            email=data['email'],
            phone=data.get('phone'),
            user_type=user_type,
            description=data.get('description'),
            website=data.get('website'),
            instagram=data.get('instagram'),
            facebook=data.get('facebook')
        )
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify(user.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """Obter um usuário específico"""
    try:
        user = User.query.get_or_404(user_id)
        user_data = user.to_dict()
        user_data['average_rating'] = user.get_average_rating()
        user_data['total_reviews'] = user.reviews_received.count()
        return jsonify(user_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    """Atualizar um usuário"""
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        # Atualizar campos permitidos
        allowed_fields = ['name', 'phone', 'description', 'website', 'instagram', 'facebook']
        for field in allowed_fields:
            if field in data:
                setattr(user, field, data[field])
        
        # Verificar se o email foi alterado e se já existe
        if 'email' in data and data['email'] != user.email:
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user:
                return jsonify({'error': 'Email já cadastrado'}), 400
            user.email = data['email']
        
        db.session.commit()
        return jsonify(user.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    """Deletar um usuário"""
    try:
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        return jsonify({'message': 'Usuário deletado com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/providers', methods=['GET'])
def get_providers():
    """Listar todos os prestadores de serviço"""
    try:
        providers = User.query.filter_by(user_type=UserType.PROVIDER).all()
        providers_data = []
        for provider in providers:
            provider_data = provider.to_dict()
            provider_data['average_rating'] = provider.get_average_rating()
            provider_data['total_reviews'] = provider.reviews_received.count()
            providers_data.append(provider_data)
        return jsonify(providers_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/users/clients', methods=['GET'])
def get_clients():
    """Listar todos os clientes"""
    try:
        clients = User.query.filter_by(user_type=UserType.CLIENT).all()
        clients_data = []
        for client in clients:
            client_data = client.to_dict()
            client_data['average_rating'] = client.get_average_rating()
            client_data['total_reviews'] = client.reviews_received.count()
            clients_data.append(client_data)
        return jsonify(clients_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

