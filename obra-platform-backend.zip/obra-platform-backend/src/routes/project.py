from flask import Blueprint, request, jsonify
from src.models.user import db, Project, User, ServiceCategory, ProjectStatus

project_bp = Blueprint('project', __name__)

@project_bp.route('/projects', methods=['GET'])
def get_projects():
    """Listar todos os projetos"""
    try:
        projects = Project.query.all()
        return jsonify([project.to_dict() for project in projects])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects', methods=['POST'])
def create_project():
    """Criar um novo projeto"""
    try:
        data = request.get_json()
        
        # Validação básica
        required_fields = ['title', 'description', 'category', 'location', 'client_id']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se o cliente existe
        client = User.query.get(data['client_id'])
        if not client:
            return jsonify({'error': 'Cliente não encontrado'}), 404
        
        # Verificar se a categoria é válida
        try:
            category = ServiceCategory(data['category'])
        except ValueError:
            return jsonify({'error': 'Categoria inválida'}), 400
        
        project = Project(
            title=data['title'],
            description=data['description'],
            category=category,
            location=data['location'],
            budget_min=data.get('budget_min'),
            budget_max=data.get('budget_max'),
            client_id=data['client_id']
        )
        
        db.session.add(project)
        db.session.commit()
        
        return jsonify(project.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>', methods=['GET'])
def get_project(project_id):
    """Obter um projeto específico"""
    try:
        project = Project.query.get_or_404(project_id)
        return jsonify(project.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>', methods=['PUT'])
def update_project(project_id):
    """Atualizar um projeto"""
    try:
        project = Project.query.get_or_404(project_id)
        data = request.get_json()
        
        # Atualizar campos permitidos
        allowed_fields = ['title', 'description', 'location', 'budget_min', 'budget_max', 'status']
        for field in allowed_fields:
            if field in data:
                if field == 'status':
                    try:
                        setattr(project, field, ProjectStatus(data[field]))
                    except ValueError:
                        return jsonify({'error': 'Status inválido'}), 400
                else:
                    setattr(project, field, data[field])
        
        db.session.commit()
        return jsonify(project.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/<int:project_id>', methods=['DELETE'])
def delete_project(project_id):
    """Deletar um projeto"""
    try:
        project = Project.query.get_or_404(project_id)
        db.session.delete(project)
        db.session.commit()
        return jsonify({'message': 'Projeto deletado com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@project_bp.route('/projects/categories', methods=['GET'])
def get_categories():
    """Listar todas as categorias de serviço"""
    categories = [{'value': cat.value, 'label': cat.value.replace('_', ' ').title()} for cat in ServiceCategory]
    return jsonify(categories)

@project_bp.route('/projects/by-category/<category>', methods=['GET'])
def get_projects_by_category(category):
    """Listar projetos por categoria"""
    try:
        try:
            service_category = ServiceCategory(category)
        except ValueError:
            return jsonify({'error': 'Categoria inválida'}), 400
        
        projects = Project.query.filter_by(category=service_category).all()
        return jsonify([project.to_dict() for project in projects])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

