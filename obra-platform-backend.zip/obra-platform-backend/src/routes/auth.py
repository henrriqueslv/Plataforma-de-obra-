from flask import Blueprint, request, jsonify, session
from src.models.user import db, User, UserType
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    """Registra um novo usuário"""
    try:
        data = request.get_json()
        
        # Validação dos campos obrigatórios
        required_fields = ['name', 'email', 'password', 'user_type']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Verifica se o email já existe
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email já cadastrado'}), 400
        
        # Valida o tipo de usuário
        try:
            user_type = UserType(data['user_type'])
        except ValueError:
            return jsonify({'error': 'Tipo de usuário inválido'}), 400
        
        # Cria o novo usuário
        user = User(
            name=data['name'],
            email=data['email'],
            user_type=user_type,
            phone=data.get('phone'),
            description=data.get('description'),
            website=data.get('website'),
            instagram=data.get('instagram'),
            facebook=data.get('facebook')
        )
        
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        # Faz login automático após o registro
        session['user_id'] = user.id
        session['user_type'] = user.user_type.value
        user.update_last_login()
        db.session.commit()
        
        return jsonify({
            'message': 'Usuário registrado com sucesso',
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Faz login do usuário"""
    try:
        data = request.get_json()
        
        # Validação dos campos obrigatórios
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email e senha são obrigatórios'}), 400
        
        # Busca o usuário pelo email
        user = User.query.filter_by(email=data['email']).first()
        
        if not user or not user.check_password(data['password']):
            return jsonify({'error': 'Email ou senha incorretos'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'Conta desativada'}), 401
        
        # Cria a sessão
        session['user_id'] = user.id
        session['user_type'] = user.user_type.value
        user.update_last_login()
        db.session.commit()
        
        return jsonify({
            'message': 'Login realizado com sucesso',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """Faz logout do usuário"""
    session.clear()
    return jsonify({'message': 'Logout realizado com sucesso'}), 200

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    """Retorna os dados do usuário logado"""
    try:
        user_id = session.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'Usuário não autenticado'}), 401
        
        user = User.query.get(user_id)
        
        if not user or not user.is_active:
            session.clear()
            return jsonify({'error': 'Usuário não encontrado ou inativo'}), 401
        
        return jsonify({
            'user': user.to_dict(),
            'authenticated': True
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/check', methods=['GET'])
def check_auth():
    """Verifica se o usuário está autenticado"""
    user_id = session.get('user_id')
    user_type = session.get('user_type')
    
    if user_id and user_type:
        user = User.query.get(user_id)
        if user and user.is_active:
            return jsonify({
                'authenticated': True,
                'user_id': user_id,
                'user_type': user_type,
                'user': user.to_dict()
            }), 200
    
    return jsonify({
        'authenticated': False,
        'user_id': None,
        'user_type': None,
        'user': None
    }), 200

@auth_bp.route('/change-password', methods=['POST'])
def change_password():
    """Altera a senha do usuário logado"""
    try:
        user_id = session.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'Usuário não autenticado'}), 401
        
        data = request.get_json()
        
        if not data.get('current_password') or not data.get('new_password'):
            return jsonify({'error': 'Senha atual e nova senha são obrigatórias'}), 400
        
        user = User.query.get(user_id)
        
        if not user or not user.check_password(data['current_password']):
            return jsonify({'error': 'Senha atual incorreta'}), 401
        
        user.set_password(data['new_password'])
        db.session.commit()
        
        return jsonify({'message': 'Senha alterada com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

